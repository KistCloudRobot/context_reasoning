/*
 * Copyright (C) 2014 ailab.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.rosjava_context_manager;

//import javax.management.monitor.Monitor;
import rosjava_custom_srv.*;

import org.apache.commons.logging.Log;
import org.ros.message.MessageListener;
import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.NodeMain;
import org.ros.node.topic.Publisher;
import org.ros.node.topic.Subscriber;
import org.jpl7.*;
import java.util.Scanner;
import java.io.PrintStream;

/**
 * A simple {@link Subscriber} {@link NodeMain}.
 */
public class ContextListener extends AbstractNodeMain {

	int visualObjectPerceptionCount = 0;
	int visualRobotBodyPerceptionCount = 0;
	int visualRobotHandPerceptionCount = 0;
	int jointPerceptionCount = 0;

	Scanner scan;

	static Publisher<QueryServiceRequest> questioner;
	static Publisher<MonitorServiceRequest> requestor;
	static Subscriber<MonitorServiceResponse> receiver;
	static Subscriber<QueryServiceResponse> answerer;
	static Log log;

	@Override
	public GraphName getDefaultNodeName() {
		return GraphName.of("context_listener");
	}

	@Override
	public void onStart(ConnectedNode connectedNode) {
		scan = new Scanner(System.in);
		log = connectedNode.getLog();

		Subscriber<std_msgs.Float32MultiArray> object_subscriber = connectedNode.newSubscriber("/object_info",
				std_msgs.Float32MultiArray._TYPE);// Subscriber node --> object
		Subscriber<std_msgs.Float32MultiArray> visual_robot_subscriber = connectedNode
				.newSubscriber("/visual_robot_perception", std_msgs.Float32MultiArray._TYPE);// Subscriber node -->
																								// object
		Subscriber<sensor_msgs.JointState> robot_joint_subscriber = connectedNode
				.newSubscriber("/j2n6s300/joint_states", sensor_msgs.JointState._TYPE);
		//receiver = connectedNode.newSubscriber("ContextManager/Monitor/ProvisionForPM", MonitorServiceResponse._TYPE);
		answerer = connectedNode.newSubscriber("context_manager/query/provision_for_pm", QueryServiceResponse._TYPE);

		questioner = connectedNode.newPublisher("context_manager/query/reception", QueryServiceRequest._TYPE);
		requestor = connectedNode.newPublisher("context_manager/monitor/reception", MonitorServiceRequest._TYPE);

		/*
		 * System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" :
		 * "failed")); System.out.println("SWI-Prolog working from now on!!!");
		 */

		// VisualObjectPerception

		answerer.addMessageListener(new MessageListener<QueryServiceResponse>() {
			@Override
			public void onNewMessage(QueryServiceResponse response) {
				String ans = response.getResult();
				log.info(String.format("The response is : " + ans));
			}
		});

		/*receiver.addMessageListener(new MessageListener<MonitorServiceResponse>() {
			@Override
			public void onNewMessage(MonitorServiceResponse response) {
				String res = response.getPredicate() + " " + response.getParam1() + " " + response.getParam2() + " "
						+ response.getParam3() + " " + response.getParam4();
				res += " " + response.getStatus();
				log.info(String.format("The response is : " + res));

			}
		});
		*/
		
		object_subscriber.addMessageListener(new MessageListener<std_msgs.Float32MultiArray>() {
			@Override
			public void onNewMessage(std_msgs.Float32MultiArray message) {
				String result = "";
				String assertString = "";
				float x = message.getData()[0];
				float y = message.getData()[1];
				float z = message.getData()[2];
				float a = message.getData()[3];
				float b = message.getData()[4];
				float c = message.getData()[5];
				String ID = "";
				String type = "";
				int time = 0;

				// radian to degree
				a = (float) Math.toDegrees(a);
				b = (float) Math.toDegrees(b);
				c = (float) Math.toDegrees(c);

				if (message.getData()[6] == (float) 100) {
					ID = "chips_can_1";
				} else if (message.getData()[6] == (float) 101) {
					ID = "chips_can_2";
				} else if (message.getData()[6] == (float) 102) {
					ID = "chips_can_3";
				} else if (message.getData()[6] == (float) 103) {
					ID = "cracker_box_1";
				} else if (message.getData()[6] == (float) 104) {
					ID = "tomato_soup_can_1";
				} else if (message.getData()[6] == (float) 105) {
					ID = "tomato_soup_can_2";
				} else if (message.getData()[6] == (float) 106) {
					ID = "coffee_can_1";
				} else if (message.getData()[6] == (float) 107) {
					ID = "coffee_can_2";
				} else if (message.getData()[6] == (float) 108) {
					ID = "sugar_box_1";
				} else if (message.getData()[6] == (float) 109) {
					ID = "sugar_box_2";
				} else if (message.getData()[6] == (float) 110) {
					ID = "cracker_box_2";
				} else if (message.getData()[6] == (float) 111) {
					ID = "cracker_box_3";
				} else if (message.getData()[6] == (float) 112) {
					ID = "jelly_box_1";
				} else if (message.getData()[6] == (float) 113) {
					ID = "jelly_box_2";
				} else {
				}
				time = (int) (System.currentTimeMillis() / 1000);

				

				// assert data
				// type
				
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ (visualObjectPerceptionCount++)
						+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#VisualObjectPerception'";
				assertTriple(assertString);
				// startTime
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
						+ time + "'";
				assertTriple(assertString);

				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
						+ time + "'";
				updateCurrentTriple(assertString);
				// objectActedOn
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#objectActedOn' 'http://www.arbi.com/ontologies/arbi.owl#"
						+ ID + "'";
				assertTriple(assertString);
				// eventOccursAt
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
						+ ID + visualObjectPerceptionCount + "'";
				assertTriple(assertString);

				assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualObjectPerception"
						+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
						+ ID + visualObjectPerceptionCount + "'";
				updateCurrentTriple(assertString);
				// rotationMatrix3D
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D'";
				assertTriple(assertString);
				// x,y,z
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ x + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ x + "'))";
				updateCurrentTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ y + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ y + "'))";
				updateCurrentTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ z + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ z + "'))";
				updateCurrentTriple(assertString);
				// a,b,g
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ a + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ a + "'))";
				updateCurrentTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ b + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ b + "'))";
				updateCurrentTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ c + "'))";
				assertTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
						+ c + "'))";
				updateCurrentTriple(assertString);
				assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
						+ visualObjectPerceptionCount
						+ "' 'http://knowrob.org/kb/knowrob.owl#m32' literal(type('http://www.w3.org/2001/XMLSchema#double','0'))";
				assertTriple(assertString);
				// print data
				/*
				result = "[Perception_Manager/visual_object_perception] time:"+time+
				"  Object_name:" + ID + ", Object Pose(X: " + x + " Y: "+ y+ " Z: " + z + "),Object Orientation(A: " + 
				a+ " B: " + b+ " G: " + c;
				System.out.println(result);*/
			}
		});

		// VisualRobotPerception
		visual_robot_subscriber.addMessageListener(new MessageListener<std_msgs.Float32MultiArray>() {
			@Override
			public void onNewMessage(std_msgs.Float32MultiArray message) {
				String result = "";
				String assertString = "";
				float x = message.getData()[0];
				float y = message.getData()[1];
				float z = message.getData()[2];
				float a = message.getData()[3];
				float b = message.getData()[4];
				float c = message.getData()[5];
				String ID = "";
				String type = "";
				int time = 0;

				// radian to degree
				a = (float) Math.toDegrees(a);
				b = (float) Math.toDegrees(b);
				c = (float) Math.toDegrees(c);

				if (message.getData()[6] == (float) 10) {
					ID = "robot_body";
				} else if (message.getData()[6] == (float) 11) {
					ID = "Jaco_1";
				} else {
				}
				time = (int) (System.currentTimeMillis() / 1000);

				// assert data
				if (ID.equals("robot_body")) {
					// type
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ (visualRobotBodyPerceptionCount++)
							+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#VisualRobotBodyPerception'";
					assertTriple(assertString);
					// startTime
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					updateCurrentTriple(assertString);
					// objectActedOn
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#objectActedOn' 'http://www.arbi.com/ontologies/arbi.owl#"
							+ ID + "'";
					assertTriple(assertString);
					// eventOccursAt
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
							+ ID + visualRobotBodyPerceptionCount + "'";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotBodyPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
							+ ID + visualRobotBodyPerceptionCount + "'";
					updateCurrentTriple(assertString);
					// rotationMatrix3D
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D'";
					assertTriple(assertString);
					// x,y,z
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ x + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ x + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ y + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ y + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ z + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ z + "'))";
					updateCurrentTriple(assertString);
					// a,b,g
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ a + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ a + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ b + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ b + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ c + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ c + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotBodyPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m32' literal(type('http://www.w3.org/2001/XMLSchema#double','0'))";
					assertTriple(assertString);
				} else if (ID.equals("Jaco_1")) {
					// type
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ (visualRobotHandPerceptionCount++)
							+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#VisualRobotHandPerception'";
					assertTriple(assertString);
					// startTime
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					updateCurrentTriple(assertString);
					// objectActedOn
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#objectActedOn' 'http://www.arbi.com/ontologies/arbi.owl#"
							+ ID + "'";
					assertTriple(assertString);
					// eventOccursAt
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
							+ ID + visualRobotHandPerceptionCount + "'";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#visualRobotHandPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#eventOccursAt' 'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_"
							+ ID + visualRobotHandPerceptionCount + "'";
					updateCurrentTriple(assertString);
					// rotationMatrix3D
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D'";
					assertTriple(assertString);
					// x,y,z
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ x + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m03' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ x + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ y + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m13' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ y + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ z + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m23' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ z + "'))";
					updateCurrentTriple(assertString);
					// a,b,g
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ a + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m02' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ a + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ b + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m12' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ b + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ c + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ "' 'http://knowrob.org/kb/knowrob.owl#m22' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ c + "'))";
					updateCurrentTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#rotationMatrix3D_" + ID
							+ visualRobotHandPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#m32' literal(type('http://www.w3.org/2001/XMLSchema#double','0'))";
					assertTriple(assertString);
					
				}
				// print data
				 result = "[Perception_Manager/Visual_robot_perception] " + "time:"+time+" Object_name:" + ID + ", Object Pose(X: " + x + " Y: "+ y+ " Z: " + z + "), Object Orientation(A: " + a+ " B: " + b+ " G: " + c +")";
				 System.out.println(result);
			}
		});

		// JointPerception
		robot_joint_subscriber.addMessageListener(new MessageListener<sensor_msgs.JointState>() {

			@Override
			public void onNewMessage(sensor_msgs.JointState message) {
				int time = message.getHeader().getStamp().secs;
				String assertString = "";
				String name;
				double position;
				double velocity;
				double effort;
				String result_joint;

				for (int i = 0; i < message.getName().size(); i++) {// 크기만큼 반복
					name = message.getName().get(i);
					position = message.getPosition()[i];
					position = Math.toDegrees(position);
					if (message.getVelocity().length > 0)
						velocity = message.getVelocity()[i];
					else
						velocity = 0;
					if (message.getEffort().length > 0)
						effort = message.getEffort()[i];
					else
						effort = 0;

					// assert data
					// type
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + (jointPerceptionCount++)
							+ "' 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type' 'http://knowrob.org/kb/knowrob.owl#JointPerception'";
					assertTriple(assertString);
					// startTime
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + jointPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#startTime' 'http://www.arbi.com/ontologies/arbi.owl#timepoint_"
							+ time + "'";
					updateCurrentTriple(assertString);
					// objectActedOn
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + jointPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#objectActedOn' 'http://www.arbi.com/ontologies/arbi.owl#"
							+ name + "'";
					assertTriple(assertString);
					// radius
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + jointPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#radius' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ position + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#radius' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ position + "'))";
					updateCurrentTriple(assertString);
					// velocity
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + jointPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#velocity' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ velocity + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#velocity' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ velocity + "'))";
					updateCurrentTriple(assertString);
					// effort
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception" + jointPerceptionCount
							+ "' 'http://knowrob.org/kb/knowrob.owl#effort' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ effort + "'))";
					assertTriple(assertString);
					assertString = "'http://www.arbi.com/ontologies/arbi.owl#jointPerception"
							+ "' 'http://knowrob.org/kb/knowrob.owl#effort' literal(type('http://www.w3.org/2001/XMLSchema#double','"
							+ effort + "'))";
					updateCurrentTriple(assertString);
					// print data
					 result_joint = "[Perception_Manager/jointPerception] " + "time:"+time+", Joint Name:" + name + ", Joint radius:("+position+"), Joint Velocity("+velocity+"), Joint Effort:("+effort+")";
					 System.out.println(result_joint);
				}

			}
		});

		try {
			Thread.sleep(2000);
			MonitorServiceRequest mRequest = requestor.newMessage();
			mRequest.setStatus(99);
			mRequest.setManager("ContextManager");
			requestor.publish(mRequest);
			
			while (true) {
				QueryServiceRequest qRequest = questioner.newMessage();
				qRequest.setQuery(scan.nextLine());
				qRequest.setManager("ContextManager");
				questioner.publish(qRequest);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void query(String param) {
sleep(1);

		MonitorServiceRequest request = requestor.newMessage();
		ContextManager.setMessage(request, param);
		request.setManager("ContextManager");
		requestor.publish(request);
	}

	public void assertTriple(String triple) {
sleep(1);

		MonitorServiceRequest request = requestor.newMessage();
		String[] params = triple.split(" ");
		String param = params[1] + " " + params[0] + " " + params[2] + " 0 0 3";
		ContextManager.setMessage(request, param);
		request.setManager("ContextManager");
		requestor.publish(request);
	}

	public void retractTriple(String triple){
sleep(1);

		MonitorServiceRequest request = requestor.newMessage();
		String[] params = triple.split(" ");
		String param = params[1] + " " + params[0] + " " + "O" + " 0 0 4";
		ContextManager.setMessage(request, param);
		request.setManager("ContextManager");
		requestor.publish(request);
	}

	public void updateCurrentTriple(String triple){
		retractTriple(triple);
		assertTriple(triple);
	}

public void sleep(int n){
		try{
			Thread.sleep(n);
		}catch(Exception e){}
	}

}
