:- module(arbi_convenient_service,
    [
    on_Physical/9,
    semanticObjectPose/2,
    misplaced_item/1,
    empty_displayshelf/2,
    on_Physical_count/3
    ]).







semanticPerception(Object, Perception):-
   rdfs_individual_of(Object, knowrob:'Artifact'),
   rdf(Perception, rdf:type, knowrob:'SemanticMapPerception'),
   rdf_has(Perception, knowrob:objectActedOn, Object).



semanticObjectPose(Object, Pose):-
   semanticPerception(Object, SemanticPerception),
   rdf(SemanticPerception, knowrob:eventOccursAt, Object_Matrix),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m03',literal(type(_,P1x))),atom_to_term(P1x,P1X,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m13',literal(type(_,P1y))),atom_to_term(P1y,P1Y,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m23',literal(type(_,P1z))),atom_to_term(P1z,P1Z,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m02',literal(type(_,O1a))),atom_to_term(O1a,O1A,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m12',literal(type(_,O1b))),atom_to_term(O1b,O1B,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m22',literal(type(_,O1c))),atom_to_term(O1c,O1C,_),
   rdf(Object_Matrix,'http://knowrob.org/kb/knowrob.owl#m32',literal(type(_,O1d))),atom_to_term(O1d,O1D,_),
   Pose = [P1X, P1Y, P1Z, O1A, O1B, O1C, O1D].



getAngle(Radian, Angle):-
   Angle is ( Radian * (180/3.14)).
getRadian(Angle, Radian):-
   Radian is ( Angle * (3.14 / 180)).


%getOrientatedPoint(Object, OrientatedPoint):-
%.




on_Physical(Top, Bottom,P,TZ,BZ,TH,BH,THhalf,BHhalf) :-
  distinct(pre_on_Physical(Top, Bottom,P,TZ,BZ,TH,BH,THhalf,BHhalf)). %중복의 제거


%TopX,..., TopOrientationX
pre_on_Physical(Top, Bottom,P,TZ,BZ,TH,BH,THhalf,BHhalf) :-

       rdfs_individual_of(Top,  knowrob:'SpatialThing-Localized'),
       rdfs_individual_of(Bottom,  knowrob:'SpatialThing-Localized'),
       Top \= Bottom,

	currentObjectPose(Top, Tpose),
	
	semanticObjectPose(Bottom, Bpose),
  objectSize(Top, Tsize),
  objectSize(Bottom, Bsize),
      [TX,TY,TZ,ToX, ToY, ToZ, ToW|_]=Tpose,    
      [BX,BY,BZ, BoX, BoY, BoZ, BoW|_]=Bpose,
      [_,_,TH|_]=Tsize,
      [BD,BW,BH|_]=Bsize,
      

      <( BZ, TZ ),
      
      
      THhalf is TH*0.5,
      BHhalf is BH*0.5,
      
      abs((TZ-THhalf) - (BZ+BHhalf))<0.04,
      nl,
      print(Top),
      nl,
      print(Bottom),
      nl,
      P is abs((TZ-THhalf) - (BZ+BHhalf)),
      print(P),
      nl.
      %=<( (BX - (BW*0.5)), TX ), >=( (BX + (BW*0.5)), TX ),
      %=<( (BY - (0.5*BD)), TY ), >=( (BY + (0.5*BD)), TY ).
      
%물체마다 x,y,z축이 다름
%==> width, depth, height를 원하는대로 정하게 되면 회전이 어떻게 될지를 알 수 없음
%회전에 따라 생각하기 어려운데...어떨게 해야하나....
%책상이냐, 선반이냐에 따라 따로 판단하기 어려움...







%placed_object_onTheShelf_incorrectly(-Object, +Shelf)
placed_object_onTheShelf_incorrectly(Object, Shelf):-

  currentObjectPerception(On_Object, CurrentPerception),                 %최근 인식 정보 물체 가져옴
  rdf(Shelf, knowrob:storagePlaceForObjectType, literal(type(_,Type))),   %shelf위에 올라가야할 물체 class가져옴
  findall(On_Object, (not(type(On_Object, Type)),on_Physical(On_Object, Shelf)),Object) 
                                                                    %올라가야할 물체와 타입이 다른데 선반 위에 있는 물체 가져옴
  .





%typed_misplaced_item(-Item, +ItemType, +Shelf):-
typed_misplaced_item(Item, ItemType, Shelf):-
    currentObjectPerception(Item, CurrentPerception),
    on_Physical(Item, Shelf),
    not(type(Item, ItemType)).


%misplaced_item(-Item)
misplaced_item(Item):-
(typed_misplaced_item(Item, 'http://knowrob.org/kb/knowrob.owl#ChipsCan','http://knowrob.org/kb/knowrob.owl#chipsCanShelf01'),
  not(type(Item, 'http://knowrob.org/kb/knowrob.owl#ChipsCan'))
  );
(typed_misplaced_item(Item, 'http://knowrob.org/kb/knowrob.owl#TomatoSoupCan', 'http://knowrob.org/kb/knowrob.owl#tomatoSoupCanShelf01'),
    not(type(Item, 'http://knowrob.org/kb/knowrob.owl#SoupCan'))
).



on_Physical_count(Count, Top, Bottom):-
  findall(Top, on_Physical(Top, Bottom),Objects),
  length(Objects, Count)
.

%displayShelfFor(+Shelf, -ItemType)
displayShelfFor(Shelf, ItemType):-
  rdf(Shelf, knowrob:storagePlaceForObjectType, literal(type(_,ItemType)))
.

%pre_empty_displayshelf(-Shelf, +Rack):-
pre_empty_displayshelf(Shelf, Rack):-
    rdf(DisplayShelf, 'http://knowrob.org/kb/knowrob.owl#physicalPartOf', Rack),
    rdfs_individual_of(DisplayShelf,  knowrob:'DisplayShelf'),
    displayShelfFor(DisplayShelf, ItemType),
    currentObjectPerception(Item, CurrentPerception),
    (
      on_Physical_count(Count, Item, DisplayShelf),
      findall(DisplayShelf, (not(on_Physical(Item, DisplayShelf)),(Count is 0)), Shelf1)
     ),
    ( 
      type(Item, ItemType),
      on_Physical_count(Count, Item, DisplayShelf),
      findall(DisplayShelf, (on_Physical(Item, DisplayShelf),(Count is 0)), Shelf2)
    ),
    append(Shelf1, Shelf2, Shelf3),
    list_to_set(Shelf3, Shelf)
    .

empty_displayshelf(Shelf, Rack):-
  distinct(pre_empty_displayshelf(Shelf, Rack)).















%numberOfObjects_onTheShelf(-Number, +Type, +Shelf)
%numberOfObjects_onTheShelf(Number, Type, Shelf):-
%  currentObjectPerception(Object, CurrentPerception),     %최근 물체 인식 정보
%  type(Object, Type),                                     %물체 타입 비교
%  %not(rdf(Object, rdf:type, owl:'NamedIndividual')),     
%  findall(Object, on_Physical(Object, Shelf),Objects),    %특정 shelf 위에 있는 필요 타입의 물체를 list로 가져옴
%  length(Objects, Number)                                 %list의 수를 셈
%.
